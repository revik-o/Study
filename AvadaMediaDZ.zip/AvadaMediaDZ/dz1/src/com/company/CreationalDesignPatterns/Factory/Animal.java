package com.company.CreationalDesignPatterns.Factory;

public interface Animal {
    void someSound();
}
