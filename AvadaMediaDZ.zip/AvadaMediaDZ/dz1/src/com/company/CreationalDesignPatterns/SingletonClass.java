package com.company.CreationalDesignPatterns;

public class SingletonClass {

    public static int SOCKET_PORT = 8080;
    public static String GET_LOCAL_IP() {
        return "127.0.0.1";
    }

}
