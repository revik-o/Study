package com.company.CreationalDesignPatterns.AbstractFactory;

public class SomeClass4 implements SomeInterface2 {
    @Override
    public void someMethod2() {
        System.out.println("This message from Class 4");
    }
}
