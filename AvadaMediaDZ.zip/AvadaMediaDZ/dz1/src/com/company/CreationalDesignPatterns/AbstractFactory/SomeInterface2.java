package com.company.CreationalDesignPatterns.AbstractFactory;

public interface SomeInterface2 {
    void someMethod2();
}
