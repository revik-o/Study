package com.company.CreationalDesignPatterns.AbstractFactory;

public class SomeClass1 implements SomeInterface1 {
    @Override
    public void someMethod() {
        System.out.println("This message from Class 1");
    }
}
