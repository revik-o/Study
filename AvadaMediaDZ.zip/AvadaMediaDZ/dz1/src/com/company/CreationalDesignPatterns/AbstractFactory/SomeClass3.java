package com.company.CreationalDesignPatterns.AbstractFactory;

public class SomeClass3 implements SomeInterface1 {

    @Override
    public void someMethod() {
        System.out.println("This message from Class 3");
    }
}
