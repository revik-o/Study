package com.company.CreationalDesignPatterns.AbstractFactory;

public interface SomeInterface1 {
    void someMethod();
}
