package com.company.CreationalDesignPatterns.Prototype;

public interface Copyable {
    Object copy();
}
