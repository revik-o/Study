package com.company.ChainOfResponsibility;

public class Priority {
    public static int first = 1;
    public static int second = 2;
    public static int third = 3;
}
