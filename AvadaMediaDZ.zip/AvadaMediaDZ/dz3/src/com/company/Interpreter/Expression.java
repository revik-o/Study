package com.company.Interpreter;

public interface Expression {
    int interpreter(Expression context);
}
