package com.company.Command;

public interface Command {
    void execute();
}
