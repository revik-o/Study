package com.company.Command;

public class DataBase {
    public void insert() {
        System.out.println("insert to database");
    }
    public void update() {
        System.out.println("update to database");
    }
    public void delete() {
        System.out.println("delete to database");
    }
    public void select() {
        System.out.println("select from database");
    }
}
