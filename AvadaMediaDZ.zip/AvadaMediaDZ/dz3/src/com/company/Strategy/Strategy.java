package com.company.Strategy;

public interface Strategy {
    void sort(int[] array);
}
