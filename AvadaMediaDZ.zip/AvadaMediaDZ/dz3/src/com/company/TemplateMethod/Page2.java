package com.company.TemplateMethod;

public class Page2 extends Template {
    @Override
    public void mid() {
        System.out.println("logic from page2");
    }
}
