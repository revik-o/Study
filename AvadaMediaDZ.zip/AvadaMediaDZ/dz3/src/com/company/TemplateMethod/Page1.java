package com.company.TemplateMethod;

public class Page1 extends Template {
    @Override
    public void mid() {
        System.out.println("logic from page1");
    }
}
