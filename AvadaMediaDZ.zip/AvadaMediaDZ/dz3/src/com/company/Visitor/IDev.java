package com.company.Visitor;

public interface IDev {
    void create(IProject iProject);
}
