package com.company.Visitor;

public interface IProject {
    void doJob(IDev iDev);
}
