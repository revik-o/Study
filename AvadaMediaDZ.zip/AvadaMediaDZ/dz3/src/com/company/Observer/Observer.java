package com.company.Observer;

public interface Observer {
    void event(String someData);
}
