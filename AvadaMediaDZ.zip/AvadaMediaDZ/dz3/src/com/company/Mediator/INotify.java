package com.company.Mediator;

public interface INotify {
    void notifyAll(String s);
}