package com.company.Mediator;

public interface SomePerson {
    void message(String s);
    String getName();
}
