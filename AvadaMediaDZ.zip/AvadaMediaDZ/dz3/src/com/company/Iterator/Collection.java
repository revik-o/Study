package com.company.Iterator;

public interface Collection {
    Iterator getIterator();
}
