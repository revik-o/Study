package com.company.State;

public interface State {
    void doSomething();
}
