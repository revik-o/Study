package com.company.State;

public class RestState implements State {
    @Override
    public void doSomething() {
        System.out.println("Rest");
    }
}
