package com.company.State;

public class Work implements State {
    @Override
    public void doSomething() {
        System.out.println("work");
    }
}
