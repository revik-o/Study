package com.company.adapter;

public interface SomeJavaApp {

    void selectObject();

    void insertObject();

    void updateObject();

    void deleteObject();

}
