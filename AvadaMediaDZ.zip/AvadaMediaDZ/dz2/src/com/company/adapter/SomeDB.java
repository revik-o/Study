package com.company.adapter;

public interface SomeDB {

    void select();

    void insert();

    void update();

    void delete();

}
