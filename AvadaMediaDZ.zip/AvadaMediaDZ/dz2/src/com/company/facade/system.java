package com.company.facade;

public class system {
    public void switchOn() {
        System.out.println("System is on");
    }
    public void switchOff() {
        System.out.println("System is on");
    }
}
