package com.company.facade;

public class HDD {
    public void startOS() {
        System.out.println("Start OS");
    }
    public void closeOS() {
        System.out.println("Close OS");
    }
}
