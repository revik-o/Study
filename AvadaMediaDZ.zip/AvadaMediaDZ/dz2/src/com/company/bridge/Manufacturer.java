package com.company.bridge;

public interface Manufacturer {
    void show();
}
