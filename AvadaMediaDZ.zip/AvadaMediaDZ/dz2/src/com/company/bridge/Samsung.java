package com.company.bridge;

public class Samsung implements Manufacturer {
    @Override
    public void show() {
        System.out.println("Samsung");
    }
}
