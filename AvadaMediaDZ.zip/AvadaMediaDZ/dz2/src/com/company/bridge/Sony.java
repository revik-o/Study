package com.company.bridge;

public class Sony implements Manufacturer {

    @Override
    public void show() {
        System.out.println("Sony");
    }

}
