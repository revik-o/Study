package com.company.proxy;

public interface IPage {
    void show();
}
