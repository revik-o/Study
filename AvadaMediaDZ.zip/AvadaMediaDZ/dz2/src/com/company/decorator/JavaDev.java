package com.company.decorator;

public class JavaDev implements Developer {

    @Override
    public String makeJob() {
        return "write java code";
    }
}
