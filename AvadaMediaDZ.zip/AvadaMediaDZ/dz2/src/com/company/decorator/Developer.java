package com.company.decorator;

public interface Developer {
    String makeJob();
}
