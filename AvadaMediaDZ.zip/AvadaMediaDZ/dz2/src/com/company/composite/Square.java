package com.company.composite;

public class Square implements Shape {
    @Override
    public void create() {
        System.out.println("Square is created");
    }
}
