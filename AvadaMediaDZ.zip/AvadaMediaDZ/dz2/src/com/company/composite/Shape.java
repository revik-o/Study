package com.company.composite;

public interface Shape {
    void create();
}
