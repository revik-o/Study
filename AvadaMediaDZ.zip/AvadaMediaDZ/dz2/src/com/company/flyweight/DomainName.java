package com.company.flyweight;

public class DomainName {

    public String name;

    public DomainName(String name) {
        this.name = name;
    }

}
