package ua.AvadaMedia.admin.ModelDAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import ua.AvadaMedia.admin.Model.SEOBlock;

//@Component
@Deprecated
public class SEOBlockDAO {

//    @Autowired
//    private IDelegateModelDAOHibernate<SEOBlock> delegateModelDAOHibernate;
//
//    public void add(SEOBlock... seoBlocks) {
//        delegateModelDAOHibernate.add(seoBlocks);
//    }
//
//    public void add(SEOBlock seoBlock) {
//        delegateModelDAOHibernate.add(seoBlock);
//    }

}
