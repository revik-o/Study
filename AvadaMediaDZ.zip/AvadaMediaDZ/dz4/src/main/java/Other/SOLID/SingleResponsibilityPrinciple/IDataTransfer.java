package Other.SOLID.SingleResponsibilityPrinciple;

public interface IDataTransfer {
    void sendData();
    void acceptData();
}
