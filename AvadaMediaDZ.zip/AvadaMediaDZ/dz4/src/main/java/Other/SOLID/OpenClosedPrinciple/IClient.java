package Other.SOLID.OpenClosedPrinciple;

public interface IClient {
    void connect();
}
