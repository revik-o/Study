package Other.SOLID.InterfaceSegregationPrinciple;

public interface IHeight {
    void setHeight(int height);
}
