package Other.SOLID.InterfaceSegregationPrinciple;

public interface IArea {
    int getArea();
}
