package Other.SOLID.OpenClosedPrinciple;

public interface IServer {
    void acceptClient(String clientName);
}
