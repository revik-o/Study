package Other.SOLID.DependencyInversionPrinciple;

public interface IBrand {

    String getName();
    void doSmth();

}
