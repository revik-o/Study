package Other.SOLID.InterfaceSegregationPrinciple;

public interface IWidth {
    void setWidth(int width);
}
