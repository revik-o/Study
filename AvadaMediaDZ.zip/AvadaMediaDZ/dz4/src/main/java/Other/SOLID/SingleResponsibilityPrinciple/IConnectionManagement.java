package Other.SOLID.SingleResponsibilityPrinciple;

public interface IConnectionManagement {
    void connect();
}
