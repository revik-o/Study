package Other.SOLID.LiskovSubstitutionPrinciple;

public interface IShape {
    void setWidth(int width);
    void setHeight(int height);
    int getArea();
}